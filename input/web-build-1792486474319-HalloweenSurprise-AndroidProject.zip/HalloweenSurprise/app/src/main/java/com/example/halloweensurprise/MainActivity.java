package com.example.halloweensurprise;

import android.app.Activity;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.RectF;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.IOException;

/** A local-only, one-screen Halloween jump-scare prank. No permissions or network access. */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private MediaPlayer mediaPlayer;
    private boolean scareShown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(9, 7, 13));
        getWindow().setNavigationBarColor(Color.rgb(9, 7, 13));
        showLoadingScreen();
        handler.postDelayed(this::showJumpScare, 2600);
    }

    private void applyImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private void showLoadingScreen() {
        applyImmersiveMode();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9, 7, 13));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(dp(28), dp(28), dp(28), dp(28));

        TextView pumpkin = text("🎃", 64, Color.WHITE, true);
        content.addView(pumpkin, centeredParams(-2, -2));

        TextView title = text("HALLOWEEN SYSTEM", 22, Color.rgb(255, 106, 0), true);
        title.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams titleParams = centeredParams(-2, -2);
        titleParams.topMargin = dp(24);
        content.addView(title, titleParams);

        TextView status = text("Подготавливаем праздничный сюрприз…", 16, Color.rgb(222, 214, 230), false);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = centeredParams(-1, -2);
        statusParams.topMargin = dp(14);
        content.addView(status, statusParams);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(12);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255, 106, 0)));
        progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(58, 45, 62)));
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(6));
        progressParams.topMargin = dp(30);
        content.addView(progress, progressParams);
        ObjectAnimator progressAnimation = ObjectAnimator.ofInt(progress, "progress", 12, 100);
        progressAnimation.setDuration(2350);
        progressAnimation.start();

        TextView footer = text("НЕ ЗАКРЫВАЙ ЭКРАН", 12, Color.rgb(118, 109, 129), true);
        footer.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams footerParams = centeredParams(-2, -2);
        footerParams.topMargin = dp(20);
        content.addView(footer, footerParams);

        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private void showJumpScare() {
        if (isFinishing() || isDestroyed() || scareShown) return;
        scareShown = true;
        applyImmersiveMode();

        root.removeAllViews();
        root.setBackgroundColor(Color.rgb(61, 0, 9));

        HorrorFace face = new HorrorFace(this);
        FrameLayout.LayoutParams faceParams = new FrameLayout.LayoutParams(dp(300), dp(330), Gravity.CENTER);
        faceParams.bottomMargin = dp(45);
        root.addView(face, faceParams);

        ObjectAnimator pop = ObjectAnimator.ofPropertyValuesHolder(face,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 0.35f, 1.08f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.35f, 1.08f, 1f));
        pop.setDuration(520);
        pop.setInterpolator(new DecelerateInterpolator());
        pop.start();
        playScream();

        TextView boo = text("БУУУ!", 42, Color.WHITE, true);
        boo.setShadowLayer(dp(10), 0, 0, Color.BLACK);
        FrameLayout.LayoutParams booParams = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        booParams.bottomMargin = dp(96);
        root.addView(boo, booParams);

        handler.postDelayed(this::showDoneScreen, 1900);
    }

    private void showDoneScreen() {
        if (isFinishing() || isDestroyed()) return;
        root.removeAllViews();
        root.setBackgroundColor(Color.rgb(12, 8, 17));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView icon = text("🎃", 62, Color.WHITE, true);
        content.addView(icon, centeredParams(-2, -2));

        TextView title = text("С ХЭЛЛОУИНОМ!", 28, Color.rgb(255, 119, 0), true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = centeredParams(-1, -2);
        titleParams.topMargin = dp(20);
        content.addView(title, titleParams);

        TextView message = text("Это просто пранк 😈\nНикаких данных мы не собираем.", 17, Color.rgb(224, 218, 230), false);
        message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams messageParams = centeredParams(-1, -2);
        messageParams.topMargin = dp(14);
        content.addView(message, messageParams);

        Button exit = new Button(this);
        exit.setText("Выйти");
        exit.setTextColor(Color.WHITE);
        exit.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(207, 65, 0)));
        LinearLayout.LayoutParams exitParams = centeredParams(-1, dp(52));
        exitParams.topMargin = dp(30);
        content.addView(exit, exitParams);
        exit.setOnClickListener(v -> finish());

        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
    }

    private void playScream() {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
            mediaPlayer = new MediaPlayer();
            android.content.res.AssetFileDescriptor afd = getAssets().openFd("scream.wav");
            mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mediaPlayer.setVolume(0.60f, 0.60f);
            mediaPlayer.setOnCompletionListener(mp -> {
                mp.release();
                if (mediaPlayer == mp) mediaPlayer = null;
            });
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException | IllegalStateException ignored) {
            // Visual effect still works if audio is unavailable.
        }
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(sizeSp);
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(true);
        view.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return view;
    }

    private LinearLayout.LayoutParams centeredParams(int width, int height) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.gravity = Gravity.CENTER_HORIZONTAL;
        return params;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (mediaPlayer != null) {
            try { mediaPlayer.release(); } catch (Exception ignored) { }
            mediaPlayer = null;
        }
        super.onDestroy();
    }

    /** Drawn in code so the project needs no downloaded images or image permissions. */
    private static class HorrorFace extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        HorrorFace(Context context) { super(context); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float sx = getWidth() / 300f;
            float sy = getHeight() / 330f;
            canvas.save();
            canvas.scale(sx, sy);

            // Horns
            p.setColor(Color.rgb(18, 4, 10));
            path.reset(); path.moveTo(58, 78); path.cubicTo(20, 44, 25, 18, 71, 49); path.close();
            canvas.drawPath(path, p);
            path.reset(); path.moveTo(242, 78); path.cubicTo(280, 44, 275, 18, 229, 49); path.close();
            canvas.drawPath(path, p);

            // Face silhouette
            p.setColor(Color.rgb(226, 215, 196));
            RectF head = new RectF(42, 43, 258, 285);
            canvas.drawOval(head, p);

            // Dark cheek shadows
            p.setColor(Color.rgb(91, 37, 43));
            canvas.drawOval(new RectF(42, 174, 103, 245), p);
            canvas.drawOval(new RectF(197, 174, 258, 245), p);

            // Eye sockets
            p.setColor(Color.rgb(20, 4, 11));
            path.reset(); path.moveTo(64, 112); path.lineTo(135, 132); path.lineTo(112, 177); path.lineTo(72, 162); path.close();
            canvas.drawPath(path, p);
            path.reset(); path.moveTo(236, 112); path.lineTo(165, 132); path.lineTo(188, 177); path.lineTo(228, 162); path.close();
            canvas.drawPath(path, p);

            // Glowing eyes
            p.setColor(Color.rgb(255, 28, 35));
            canvas.drawOval(new RectF(81, 138, 111, 157), p);
            canvas.drawOval(new RectF(189, 138, 219, 157), p);
            p.setColor(Color.WHITE);
            canvas.drawCircle(98, 146, 4, p);
            canvas.drawCircle(202, 146, 4, p);

            // Nose and screaming mouth
            p.setColor(Color.rgb(38, 5, 13));
            path.reset(); path.moveTo(150, 160); path.lineTo(132, 198); path.lineTo(168, 198); path.close();
            canvas.drawPath(path, p);
            RectF mouth = new RectF(91, 190, 209, 267);
            canvas.drawOval(mouth, p);
            p.setColor(Color.rgb(255, 35, 45));
            canvas.drawOval(new RectF(104, 198, 196, 258), p);

            // Teeth
            p.setColor(Color.rgb(255, 245, 220));
            for (int i = 0; i < 5; i++) {
                float x = 107 + i * 18;
                path.reset(); path.moveTo(x, 199); path.lineTo(x + 12, 199); path.lineTo(x + 6, 218); path.close();
                canvas.drawPath(path, p);
                path.reset(); path.moveTo(x, 258); path.lineTo(x + 12, 258); path.lineTo(x + 6, 241); path.close();
                canvas.drawPath(path, p);
            }

            // Cracks
            p.setColor(Color.rgb(102, 79, 80));
            p.setStrokeWidth(3f);
            p.setStyle(Paint.Style.STROKE);
            path.reset(); path.moveTo(146, 61); path.lineTo(137, 80); path.lineTo(148, 89); path.lineTo(140, 103);
            canvas.drawPath(path, p);
            path.reset(); path.moveTo(64, 183); path.lineTo(78, 194); path.lineTo(69, 210);
            canvas.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
            canvas.restore();
        }
    }
}
