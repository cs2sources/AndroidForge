@echo off
where gradle >nul 2>nul
if %errorlevel%==0 ( gradle %* & exit /b %errorlevel% )
set VERSION=8.9
set ROOT=%USERPROFILE%\.gradle\manual-wrapper
set BIN=%ROOT%\gradle-%VERSION%\bin\gradle.bat
if not exist "%BIN%" (
  if not exist "%ROOT%" mkdir "%ROOT%"
  echo Downloading Gradle %VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ROOT%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%ROOT%\gradle-%VERSION%-bin.zip' '%ROOT%'"
)
call "%BIN%" %*
